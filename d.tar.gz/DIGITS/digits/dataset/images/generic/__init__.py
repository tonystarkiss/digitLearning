# Copyright (c) 2015-2017, NVIDIA CORPORATION.  All rights reserved.
from __future__ import absolute_import

from .job import GenericImageDatasetJob

__all__ = ['GenericImageDatasetJob']
