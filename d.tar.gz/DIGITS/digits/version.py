# Copyright (c) 2016-2017, NVIDIA CORPORATION.  All rights reserved.

__version__ = '6.0.0'
